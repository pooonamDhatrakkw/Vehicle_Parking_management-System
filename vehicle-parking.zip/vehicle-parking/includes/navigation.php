<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="./dashboard.php"><span>Vechicle </span>Parking System</a>
				<ul class="nav navbar-top-links navbar-right">
					
						
					</li>
					<li class="dropdown"><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-user-circle"></em> 
					</a>
						<ul class="dropdown-menu dropdown-alerts">
							<li><a href="./myprofile.php">
								<div><em class="fa fa-user"></em> Profile</div>
							</a></li>
							<li class="divider"></li>
							<li><a href="./change-password.php">
								<div><em class="fa fa-key"></em> Change Password</div>
							</a></li>
							<li class="divider"></li>
							<li><a href="./setting.php">
								<div><em class="fa fa-cogs"></em> Settings</div>
							</a></li>
							<li class="divider"></li>
							<li><a href="./logout.php">
								<div><em class="fa fa-power-off"></em> Logout</div>
							</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
	</nav>