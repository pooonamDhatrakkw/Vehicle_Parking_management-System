<footer>
	<div class="col-sm-12">
		<p class="back-link">&copy; <?php echo date("Y"); ?> - Developed By Naseeb Bajracharya </p>
	</div>
</footer>